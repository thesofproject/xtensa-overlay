/* Customized table mapping between kernel xtregset and GDB register cache.

   Customer ID=12153; Build=0x72343; Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	352

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   43, 172,   8,   8,  4, -1, 0x0204, "br" },
  {   44, 176,  12,  12,  4, -1, 0x020c, "scompare1" },
  {   45, 180,   0,   0,  4, -1, 0x0210, "acclo" },
  {   46, 184,   4,   4,  4, -1, 0x0211, "acchi" },
  {   47, 188,  16,  16,  4, -1, 0x0220, "m0" },
  {   48, 192,  20,  20,  4, -1, 0x0221, "m1" },
  {   49, 196,  24,  24,  4, -1, 0x0222, "m2" },
  {   50, 200,  28,  28,  4, -1, 0x0223, "m3" },
  {   51, 204,   8,  40,  8,  0, 0x0030, "f0" },
  {   52, 212,  16,  48,  8,  0, 0x0031, "f1" },
  {   53, 220,  24,  56,  8,  0, 0x0032, "f2" },
  {   54, 228,  32,  64,  8,  0, 0x0033, "f3" },
  {   55, 236,  40,  72,  8,  0, 0x0034, "f4" },
  {   56, 244,  48,  80,  8,  0, 0x0035, "f5" },
  {   57, 252,  56,  88,  8,  0, 0x0036, "f6" },
  {   58, 260,  64,  96,  8,  0, 0x0037, "f7" },
  {   59, 268,  72, 104,  8,  0, 0x0038, "f8" },
  {   60, 276,  80, 112,  8,  0, 0x0039, "f9" },
  {   61, 284,  88, 120,  8,  0, 0x003a, "f10" },
  {   62, 292,  96, 128,  8,  0, 0x003b, "f11" },
  {   63, 300, 104, 136,  8,  0, 0x003c, "f12" },
  {   64, 308, 112, 144,  8,  0, 0x003d, "f13" },
  {   65, 316, 120, 152,  8,  0, 0x003e, "f14" },
  {   66, 324, 128, 160,  8,  0, 0x003f, "f15" },
  {   67, 332,   0,  32,  4,  0, 0x03e8, "fcr" },
  {   68, 336,   4,  36,  4,  0, 0x03e9, "fsr" },
  {   69, 340,   0, 168,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   70, 344,   4, 172,  4,  1, 0x03f1, "ae_bithead" },
  {   71, 348,   8, 176,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   72, 352,  12, 180,  4,  1, 0x03f3, "ae_cw_sd_no" },
  {   73, 356,  16, 184,  4,  1, 0x03f6, "ae_cbegin0" },
  {   74, 360,  20, 188,  4,  1, 0x03f7, "ae_cend0" },
  {   75, 364,  24, 192,  8,  1, 0x1010, "aed0" },
  {   76, 372,  32, 200,  8,  1, 0x1011, "aed1" },
  {   77, 380,  40, 208,  8,  1, 0x1012, "aed2" },
  {   78, 388,  48, 216,  8,  1, 0x1013, "aed3" },
  {   79, 396,  56, 224,  8,  1, 0x1014, "aed4" },
  {   80, 404,  64, 232,  8,  1, 0x1015, "aed5" },
  {   81, 412,  72, 240,  8,  1, 0x1016, "aed6" },
  {   82, 420,  80, 248,  8,  1, 0x1017, "aed7" },
  {   83, 428,  88, 256,  8,  1, 0x1018, "aed8" },
  {   84, 436,  96, 264,  8,  1, 0x1019, "aed9" },
  {   85, 444, 104, 272,  8,  1, 0x101a, "aed10" },
  {   86, 452, 112, 280,  8,  1, 0x101b, "aed11" },
  {   87, 460, 120, 288,  8,  1, 0x101c, "aed12" },
  {   88, 468, 128, 296,  8,  1, 0x101d, "aed13" },
  {   89, 476, 136, 304,  8,  1, 0x101e, "aed14" },
  {   90, 484, 144, 312,  8,  1, 0x101f, "aed15" },
  {   91, 492, 152, 320,  8,  1, 0x1020, "u0" },
  {   92, 500, 160, 328,  8,  1, 0x1021, "u1" },
  {   93, 508, 168, 336,  8,  1, 0x1022, "u2" },
  {   94, 516, 176, 344,  8,  1, 0x1023, "u3" },
  { 0 }
};

